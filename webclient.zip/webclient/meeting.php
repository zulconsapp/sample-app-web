<?php

function generate_signature ( $api_key, $api_sercet, $meeting_number, $role){

	$time = time() * 1000; //time in milliseconds (or close enough)

	$data = base64_encode($api_key . $meeting_number . $time . $role);

	$hash = hash_hmac('sha256', $data, $api_sercet, true);

	$_sig = $api_key . "." . $meeting_number . "." . $time . "." . $role . "." . base64_encode($hash);

	//return signature, url safe base64 encoded
	return rtrim(strtr(base64_encode($_sig), '+/', '-_'), '=');
}

$api_key = 'KEY';
$api_secret = 'SECRET';


$meeting = $_GET['meeting_number'];

$signature = generate_signature($api_key, $api_secret, $meeting, 0);

?>

<html>
	<head>
		<title>Zoom Web Client</title>
		<meta charset="utf-8" />

	</head>
	<body>
		<div class="main">
			<div id='root'>
			</div>
		</div>

		<script src="lib/react.min.js"></script>
		<script src="lib/react-dom.min.js"></script>
		<script src="lib/redux.min.js"></script>
		<script src="lib/redux-thunk.min.js"></script>
		<script src="lib/jquery.min.js"></script>
		<script src="lib/jquery.i18n.js"></script>
		<script src="https://source.zoom.us/zoom-meeting-1.0.0.min.js"></script>
		<script src="js/customer.js"></script>
	</body>
</html>

<script>
    ZoomMtg.init({
        debug: true,
        leaveUrl: 'http://www.zoom.us',
        success: function () {
            ZoomMtg.join({
                meetingNumber: '<?=$meeting?>',
                userName: 'User Name',
                signature: '<?=$signature?>',
                apiKey: '<?=$api_key?>'
            });
        }

    })
</script>